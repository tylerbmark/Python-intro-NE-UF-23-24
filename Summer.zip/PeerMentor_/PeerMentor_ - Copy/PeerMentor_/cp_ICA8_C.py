# cp_ICA8_C.py

#####################################################################
#
#   An object-oriented program to read a list of Customer objects for
#   the provided CSV file (customers.csv) that contains customer data
#   and allow the user to display the data for a customer by
#   specifying the customer’s ID.
#
#   Input(s):
#
#   - Filename (customers.csv)
#   - Customer ID
#
#   Output(s):
#   
#   - Customer name
#   - Customer address
#
#   By: Cory Price
#
#####################################################################

import csv

class Customer:

    # private constructor
    def __init__(self, customerID, firstName, lastName, companyName, address, city, state, zipCode):
        # eight attributes
        self.customerID = customerID
        self.firstName = firstName
        self.lastName = lastName
        self.companyName = companyName
        self.address = address
        self.city = city
        self.state = state
        self.zipCode = zipCode

    # method to return the full name
    def fullName(self):
        return f'{self.firstName} {self.lastName}'

    # method to return the full address
    def fullAddress(self):
        if self.companyName:
            return f'{self.companyName}\n{self.address}\n{self.city}, {self.state} {self.zipCode}'
        else:
            return f'{self.address}\n{self.city}, {self.state} {self.zipCode}'

# function to read the file and create a customer object
def read_customer_data(filename):
    customers = []
    with open(filename, 'r', newline='') as file:
        reader = csv.reader(file)
        next(reader)  # Skip the header row
        for row in reader:
            customerID, firstName, lastName, companyName, address, city, state, zipCode = row
            customerID = int(customerID)  # Convert customerID to an integer
            customer = Customer(customerID, firstName, lastName, companyName, address, city, state, zipCode)
            customers.append(customer)
    return customers

# function to find and return a customer object with the given customer ID
def find_customer(customers, customerID):
    for customer in customers:
        if customer.customerID == customerID:
            return customer
    return None

def main():

    # title
    print('\nCustomer Viewer\n')

    # get correct filename
    while True:
        try:
            filename = str(input('Enter a filename (.csv): '))
            customers = read_customer_data(filename)
            break
        except FileNotFoundError:
            print('Cannot find the csv file. Try again!')
            continue

    again = 'y'
    # set up continuation loop
    while again[0].lower() == 'y':

        # get customer ID
        customerID = int(input('Enter a customer ID: '))
        print()

        # use functions and methods to find the customer from the ID and return the correct info
        customer = find_customer(customers, customerID)
        if customer:
            print(f'{customer.fullName()}')
            print(f'{customer.fullAddress()}')
            print()
        else:
            print('No customer with that ID.\n')

        # ask if user wants to repeat the program
        again = str(input('Want to enter another customer ID? (y/n): '))
        print()

    print('Thank you! Bye!')    
    
# if started as the main module, call the main function    
if __name__ == "__main__":
    main()
