# Data Processing object oriented program
# builds off Crunchy
import Crunchy as cc
import matplotlib.pyplot
import dask as dd
import pandas as pd
import numpy as np
import csv

crunch = cc.CrunchyTxt('CrunchMCNPtxt.txt')
crunch = crunch.read_txt()
positions = crunch.find('1tally fluctuation charts')
print(positions)