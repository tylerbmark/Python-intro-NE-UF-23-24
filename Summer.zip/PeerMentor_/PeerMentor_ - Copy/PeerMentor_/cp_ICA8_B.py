# cp_ICA8_B.py

#####################################################################
#
#   An object-oriented program to create a deck of cards, shuffle
#   them, and deal the specified number of cards to the player.
#
#   Input(s):
#
#   - Number of cards desired
#
#   Output(s):
#   
#   - The cards drawn from the deck
#   - The number of cards remaining in the deck
#
#   By: Cory Price
#
#####################################################################

import random

class Card:

    # private constructor
    def __init__(self, rank = '', suit = ''):
        # two private attributes for height and width
        self.__rank = rank
        self.__suit = suit

    # public accessors for the private attributes
    def getRank(self):
        return self.__rank
    
    def getSuit(self):
        return self.__suit

    # public mutators for the private attributes
    def setRank(self, rank):
        self.__rank = rank
        
    def setSuit(self, suit):
        self.__suit = suit

    # one method using the two attributes
    def getStr(self):
        card = self.__rank.title()+' of '+self.__suit.title()
        return card

class Deck:

    # private constructor
    def __init__(self):
        # three private attributes for ranks, suits, and cards
        self.__ranks = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack', 'Queen', 'King', 'Ace']
        self.__suits = ['Clubs', 'Diamonds', 'Hearts', 'Spades']
        self.__cards = [Card(rank, suit) for rank in self.__ranks for suit in self.__suits]

    # three methods
    def shuffle(self):
        random.shuffle(self.__cards)

    def count(self):
        return len(self.__cards)

    def dealCard(self):
        if self.count() > 0:
            return self.__cards.pop()
        else:
            return None

def main():

    print('\nCard Dealer\n')
    print('I have shuffled a deck of 52 cards.\n')

    # create Deck object without arguments
    deck = Deck()

    # shuffle deck
    deck.shuffle()

    # get user input
    cards_to_deal = int(input('How many cards would you like?: '))

    # initialize list
    dealt_cards = []

    # deal desired number of cards
    for ii in range(cards_to_deal):
        card = deck.dealCard()
        if card:
            dealt_cards.append(card)

    # display cards
    print('\nHere are your cards:')
    for card in dealt_cards:
        print(card.getStr())

    # display remaining number of cards
    print()
    print('There are',deck.count(),'cards left in the deck.')
    print()

    print('Good luck!\n')
    
# if started as the main module, call the main function    
if __name__ == "__main__":
    main()
