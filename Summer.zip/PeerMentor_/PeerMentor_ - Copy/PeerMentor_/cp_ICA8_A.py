# cp_ICA8_A.py

#####################################################################
#
#   An object-oriented program to perform calculations on a
#   rectangle.
#
#   Input(s):
#
#   - Height
#   - Width
#
#   Output(s):
#   
#   - Perimeter
#   - Area
#
#   By: Cory Price
#
#####################################################################

class Rectangle:

    # private constructor
    def __init__(self, height = 0, width = 0):
        # two private attributes for height and width
        self.__height = height
        self.__width = width

    # public accessors for the private attributes
    def getHeight(self):
        return self.__height
    
    def getWidth(self):
        return self.__width

    # public mutators for the private attributes
    def setHeight(self, height):
        self.__height = height
        
    def setWidth(self, width):
        self.__width = width

    # three methods that use the two attributes
    def setPerimeter(self):
        perimeter = (2*self.__height)+(2*self.__width)
        print('Perimeter:',perimeter)
        return perimeter

    def setArea(self):
        area = (self.__height)*(self.__width)
        print('Area:     ',area)
        return area

    def setStr(self):
        for row in range(self.__height):
            for col in range(self.__width):
                if row == 0 or row == self.__height-1:
                    print('*', end = ' ')
                elif col == 0 or col == self.__width-1:
                    print('*', end = ' ')
                else:
                    print(' ', end = ' ')
            print()
        print()
        return
    

def main():
    
    # display title
    print('\nRectangle Calculator\n')

    again = 'y'
    while again[0].lower() == 'y':

        # create Rectangle object without arguments
        rectangle = Rectangle()

        # get user inputs (height and width)
        newHeight = int(input('Height:    '))
        newWidth = int(input('Width:     '))

        # set height and width to the Rectangle object
        rectangle.setHeight(newHeight)
        rectangle.setWidth(newWidth)

        # display outputs
        rectangle.setPerimeter()
        rectangle.setArea()
        rectangle.setStr()

        # ask if user wants to run program again
        again = input('Do it again? (y/n): ')
        print()

    print('Thank you! Bye!')
    
# if started as the main module, call the main function    
if __name__ == "__main__":
    main()
