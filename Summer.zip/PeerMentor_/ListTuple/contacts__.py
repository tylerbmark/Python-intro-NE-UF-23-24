# contacts.py
# for gt_ICA4_B.py
'''
This module contains functions
for managing contacts

'''
def display(contacts: list) -> list:
    '''displays all contacts'''
    if len(contacts) == 0:
        print("There are no contacts available!")
    else:
        i = 1
        for row in contacts:
            print(str(i)+ "." + row[0])
            i +=1
        print()
def add(contacts: list) -> list:
    '''adds a contact'''
    name = input("Name: ")
    email = input("Email: ")
    phone = input("Phone: ")
    contact = []
    contact.append(name)
    contact.append(email)
    contact.append(phone)
    contacts.append(contact)
    print(contact[0] + " was added. \n")

def remove(contacts: list) -> list:
    '''removes a contact'''
    number = int(input("Number: "))
    if number < 1 or number > len(contacts):
        print("Invalid contact number. \n")
    else:
        contact = contacts.pop(number-1)
        print(contact[0] + " was removed.\n")

def view(contacts: list) -> list:
    '''views a contact'''
    dis = ('Name: ','Email: ',"Phone Number: ")
    number = int(input("Number: "))
    if number <1 or number > len(contacts):
        print("Invalid Contact number. \n")
    else:
        count = 0
        for i in contacts[number-1]:
            print(dis[count],i)
            count +=1
