from gt_ICA8_C import readcsv

# data mapping processing of customers.csv
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
