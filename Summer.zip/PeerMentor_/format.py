line = '{:10} {:>5}'

print('Number:', line.format(25,32))
print('Number:', line.format(32,21))

person = ({
    "name": "John",
    "age": 30,
    "city": "New York"
},{ 'name': 'jacob', 'age': 45, 'city': 'Tacoma'})


print(person[1]['name'])


person = {"name": "John", "age": 30, "city": "New York"}

keys_list = person.keys()      # ['name', 'age', 'city']
values_list = person.values()  # ['John', 30, 'New York']
items_list = person.items()    # [('name', 'John'), ('age', 30), ('city', 'New York')]

name = person.get("name")            # 'John'
profession = person.get("profession", "Unknown")  # 'Unknown' (default value since "profession" key does not exist)

age = person.pop("age")      # 30, and the key "age" is removed from the dictionary



person = {"name": "John", "age": 30, "city": "New York"}

# Iterating over keys
for key in person:
    print(key)  # Output: name, age, city

# Iterating over values
for value in person.values():
    print(value)  # Output: John, 30, New York

# Iterating over key-value pairs
for key, value in person.items():
    print(f"{key}: {value}")  # Output: name: John, age: 30, city: New York
