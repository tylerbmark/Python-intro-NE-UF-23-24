# These are two challenges that you can use
# to optimize your skills at coding
# As it stands, I do not know what the exam actually is
# thus I went with making them harder than what I think the exam will be
# Goodluck, and Godspeed
'''challenge #1
 Using list comprehension and multiple functions
create a program that will take two 3D vectors and
 turn it into a unit vector of the two'''
 '''For those who wish to challenge themselves, include a file handling matrix with the initial vectors,
 the unit vector and the magnitude of the two vectors.'''


 '''Challenge #2
 # creating module that will take test data from a list
 and by creating a module(s) you will be able to find the
 median, min, max, average, and number of scores evaluated
 use the test values provided to create the program
 have a function that can add new values to the list(int)
 the output should have both the median,min,max ,average of
 the initial scores and the new data from the new test values entered
 and a function to exit the main program after done using
 '''

 '''Additionally if you struggle with file management, please add a means to write,read and update a file
 bin, csv, or txt ( your choice), with the statistical data from each run compiled into the file'''



 '''Rules: 
 You may look up the equations if you do not know them, however if you use the internet for anything else
 you're really only cheating yourself.
 Using your phone time yourself, if you can do it before an hour is up, You'll be more than fine,'''























