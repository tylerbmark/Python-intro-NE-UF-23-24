# This is a little program that I put together for classes

import matplotlib.pyplot as plt
import numpy as np

class plotmaker:



