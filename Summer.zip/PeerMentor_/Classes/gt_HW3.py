# gt_HW3.py

# input: x,y
# output: calculations

# by Gentry Trimble
class Calculator:
    def __init__(self):
        self.display = ['']*10
        self.count = 0
        self.x = 0

    def functmenu(self,function):
        for i in function:
            print(i)
    def PrintDisplay(self):

        print('+---'*7 + '+')
        eq = '{:3} {:>5}'
        for line in self.display:
            if line:
                print(eq.format("|   ", line,))
            else: print(eq.format("|",""))
        print('+--'+ '+---'*6 + '-+')
    def FunctDisplay(self,command,y):
        symbol = ['+','-', 'X', '/', '^']
        if command == 'add':
            result = round(self.x + y, 3)
            sym = symbol[0]
        elif command == 'subtract':
            result = round(self.x - y, 3)
            sym = symbol[1]
        elif command == 'divide':
            result = round(self.x / y, 3)
            sym = symbol[3]
        elif command == 'multiply':
            result = round(self.x * y, 3)
            sym = symbol[2]
        elif 'exp' in command:
            result = round(self.x ** y, 3)
            sym = symbol[4]

        else:
            return 'invalid command',None
        display_line = f'{round(self.x,3):8}  {sym}  {y} = {result:3}'
        return display_line,result

    def InitialVerification(self):
        while True:
            try:
                x = float(input("Enter your first number: "))
                y = float(input("Enter your second number: "))
            except ValueError:
                print("Invalid or no input. Try again")
                continue
            else:
                self.x = x
                return y

    def inputVerification(self):
        while True:
            try:
                y = float(input("Enter another number: "))
            except ValueError:
                print('Invalid or no input. Try again.')
                continue
            else:
                return y

    def calculator(self):
        command = input("Enter function you wish to use: ")
        y = self.InitialVerification()
        self.display[self.count], self.x = self.FunctDisplay(command, y)
        self.PrintDisplay()

        while self.count != 9:
            self.count += 1
            command = input("Enter function you wish to use: ")
            y = self.inputVerification()
            self.display[self.count], self.x = self.FunctDisplay(command, y)
            self.PrintDisplay()
            print()
            if self.count >=5 and self.count <9:
                repeat = input("Would you like to continue? (y/n): ")
                if repeat != 'y': break
                else: continue


def main():
    print("\nSelf-Updating Calculator\n")
    function = ("add - adds two variables", "subtract - subtracts two variables",
                    'divide - divides two variables', 'multiply - multiplies two variables',
                    'exponent - raises current value to the new value power')
    calc = Calculator()
    calc.functmenu(function)
    print()
    calc.calculator()
    print("Thanks for using!")
if __name__ == "__main__":
    main()
