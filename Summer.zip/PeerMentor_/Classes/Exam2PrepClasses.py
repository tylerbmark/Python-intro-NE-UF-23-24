# ExamPrep2



import math
class shape:
    def __init__(self, type = 'type'):
        self.__type = type
    def compile_shape_info(self):
        info_dict = {'type': self.__type}
        return info_dict
    def display(self):
        return f"Shape Calc\nType:{self.__type}"

class Rectangle(shape):
    def __init__(self, height=0 , width=0):
        super().__init__(type = '2D')
        self.__height = height
        self.__width = width
    def setWidth(self,width):
        self.__width = width
    def setHeight(self,height):
        self.__height = height

    def getPerimeter(self):
        return 2*(self.__height + self.__width)
    def getArea(self):
        return self.__height* self.__width
    def display(self):
        return super().display() + f'\nArea: {self.getArea()}\n Perimeter: {self.getPerimeter()}'

    def compile_shape_info(self):
        info_dict = super().compile_shape_info()
        info_dict['width'] = self._Rectangle__width
        info_dict['height'] = self._Rectangle__height
        info_dict['Area'] = self.getArea()
        info_dict['Perimeter'] = self.getPerimeter()
        return info_dict

class Square(Rectangle):
    def __init__(self,length = 0.0):
        super().__init__(length,length)

class Circle(shape):
    def __init__(self,radius = 0.0):
        super().__init__(type = '2D')
        self.__radius = radius

    def setRadius(self,radius):
        self.__radius = radius

    def getArea(self):
        return math.pi* (self.__radius**2)
    def getCircumference(self):
        return 2*math.pi* self.__radius

    def display(self):
        return super().display() + f'\nArea: {self.getArea()}\nCircumference: {self.getCircumference()}'

    def compile_shape_info(self):
        info_dict = super().compile_shape_info()
        info_dict['radius'] = self._Circle__radius
        info_dict['Area'] = self.getArea()
        info_dict['Circumference'] = self.getCircumference()
        return info_dict

class ThreeDRectangle(Rectangle):
    def __init__(self, length=0.0, width=0.0, height=0.0):
        super().__init__(height=height, width=width)
        self._length = length
        self._Shape__type = '3D'  # Fixed the type attribute

    def setLength(self, length):
        self._length = length

    def getVolume(self):
        # Use the correct attribute names (_Rectangle__width and _Rectangle__height)
        return self._length * self._Rectangle__width * self._Rectangle__height

    def getSurfaceArea(self):
        # Use the correct attribute names (_Rectangle__width and _Rectangle__height)
        return 2 * (self._length * self._Rectangle__width + self._length * self._Rectangle__height + self._Rectangle__width * self._Rectangle__height)

    def display(self):
        return super().display() + f'\nVolume: {self.getVolume()}\nSurface Area: {self.getSurfaceArea()}'

    def compile_shape_info(self):
        info_dict = super().compile_shape_info()
        info_dict['length'] = self._length
        info_dict['width'] = self._Rectangle__width
        info_dict['height'] = self._Rectangle__height
        info_dict['Volume'] = self.getVolume()
        info_dict['Surface Area'] = self.getSurfaceArea()
        return info_dict

class Square3D(Square):
    def __init__(self, length=0.0):
        super().__init__(length=length)
        self._Shape__type = '3D'

    def setLength(self, length):
        self._Rectangle__height = length  # Use the correct attribute name (_Rectangle__length)

    def getVolume(self):
        # Use the correct attribute name (_Rectangle__length)
        return self._Rectangle__height ** 3

    def getSurfaceArea(self):
        # Use the correct attribute name (_Rectangle__length)
        return 6 * (self._Rectangle__height ** 2)

    def display(self):
        return super().display() + f'\nVolume: {self.getVolume()}\nSurface Area: {self.getSurfaceArea()}'

    def compile_shape_info(self):
        info_dict = super().compile_shape_info()
        info_dict['length'] = self._Rectangle__height
        info_dict['Volume'] = self.getVolume()
        info_dict['Surface Area'] = self.getSurfaceArea()
        return info_dict


class ThreeDSphere(Circle):
    def __init__(self, radius=0.0):
        super().__init__(radius=radius)
        self._Shape__type = '3D'

    def getVolume(self):
        return (4 / 3) * math.pi * (self._Circle__radius ** 3)

    def getSurfaceArea(self):
        return 4 * math.pi * (self._Circle__radius ** 2)

    def display(self):
        return super().display() + f'\nVolume: {self.getVolume()}\nSurface Area: {self.getSurfaceArea()}'

    def compile_shape_info(self):
        info_dict = super().compile_shape_info()
        info_dict['radius'] = self._Circle__radius
        info_dict['Volume'] = self.getVolume()
        info_dict['Surface Area'] = self.getSurfaceArea()
        return info_dict

class Cone(Circle):
    def __init__(self, radius=0.0, height=0.0):
        super().__init__(radius=radius)
        self.__height = height
        self._Shape__type = '3D'

    def setHeight(self, height):
        self.__height = height

    def getVolume(self):
        return (1 / 3) * math.pi * (self._Circle__radius ** 2) * self.__height

    def getSurfaceArea(self):
        base_area = super().getArea()
        lateral_area = math.pi * self._Circle__radius * math.sqrt(self._Circle__radius ** 2 + self.__height ** 2)
        return base_area + lateral_area

    def display(self):
        return super().display() + f'\nVolume: {self.getVolume()}\nSurface Area: {self.getSurfaceArea()}'

    def compile_shape_info(self):
        info_dict = super().compile_shape_info()
        info_dict['radius'] = self._Circle__radius
        info_dict['height'] = self._Cone__height
        info_dict['Volume'] = self.getVolume()
        info_dict['Surface Area'] = self.getSurfaceArea()
        return info_dict


def choose_shape(shape_type):
    shapes_menu = {
        '2d': {
            1: Rectangle,
            2: Square,
            3: Circle,
        },
        '3d': {
            1: ThreeDRectangle,
            2: ThreeDSphere,
            3: Cone,
            4: Square3D
        }
    }

    if shape_type not in shapes_menu:
        print("Invalid shape type. Supported options: 2D, 3D")
        return None

    print(f"Choose a shape to analyze ({shape_type.upper()}):")
    for idx, shape in shapes_menu[shape_type].items():
        print(f"{idx}. {shape.__name__}")

    choice = int(input("Enter your choice (1/2/3/4): "))

    if choice not in shapes_menu[shape_type]:
        print("Invalid choice.")
        return None

    shape_class = shapes_menu[shape_type][choice]

    if shape_type == '2d':
        if shape_class == Rectangle:
            height = float(input("Enter the height of the rectangle: "))
            width = float(input("Enter the width of the rectangle: "))
            return Rectangle(height=height, width=width)


        elif shape_class == Square:
            length = float(input("Enter the length of the square: "))
            return Square(length=length)
        elif shape_class == Circle:
            radius = float(input("Enter the radius of the circle: "))
            return Circle(radius=radius)
    elif shape_type == '3d':
        if shape_class == ThreeDRectangle:
            length = float(input("Enter the length of the 3D rectangle: "))
            width = float(input("Enter the width of the 3D rectangle: "))
            height = float(input("Enter the height of the 3D rectangle: "))
            return ThreeDRectangle(length=length, width=width, height=height)
        elif shape_class == ThreeDSphere:
            radius = float(input("Enter the radius of the 3D sphere: "))
            return ThreeDSphere(radius=radius)
        elif shape_class == Cone:
            radius = float(input("Enter the radius of the cone: "))
            height = float(input("Enter the height of the cone: "))
            return Cone(radius=radius, height=height)
        elif shape_class == Square3D:
            length = float(input("Enter the length of the square: "))
            return Square3D(length = length)
    return None


def main():
    print("Shape Analysis Program")
    shape_list = []
    repeat = 'y'
    while repeat.lower()[0] == 'y':
        shape_type = input("Enter the type of shape (2D or 3D): ").strip().lower()

        shape_instance = choose_shape(shape_type)
        if shape_instance:
            print(shape_instance.display())
            shape_info = shape_instance.compile_shape_info()
            print(f"Shape Information ({shape_type.upper()}):")
            for key, value in shape_info.items():
                print(f"{key}: {value}")
            shape_list.append(shape_info)
        repeat = input("Would you like to compile another dictionary?")
        for shape_info in shape_list:
            print(shape_info)
if __name__ == "__main__":
    main()


