'''Hello! Python adventurers
Welcome to Object oriented programming, you've used a bit of it in the past, basically everything
is built off it. But it can be kind of confusing to figure out initially.
Thus when boredom struck, I decided to put together something for you all!
One might ask, why use classes?
Well in truth, they're often way more data efficient than your regular modules.Thus saving memory space and
potentially runtime. '''


# Ya'll remember contacts.py? well I made it into a class

import csv

class ContactManager:
    def __init__(self, filename):
        self.filename = filename
        self.contacts = self.read_contacts_from_file()

    def write_contacts_to_file(self):
        '''Writes the contacts to a CSV file'''
        with open(self.filename, 'w', newline='') as file:
            writer = csv.writer(file)
            writer.writerows(self.contacts)

    def read_contacts_from_file(self):
        '''Reads contacts from a CSV file and returns a 2D list of contacts'''
        contacts = []
        try:
            with open(self.filename, newline='') as file:
                reader = csv.reader(file)
                for row in reader:
                    contacts.append(row)
        except FileNotFoundError:
            print(f'Cannot find the file "{self.filename}"')
            self.write_contacts_to_file()
            print(f'File "{self.filename}" has been created.')
        return contacts

    def get_contact_number(self):
        '''Asks the user for a contact number and returns a valid contact number or -1
        (for an invalid contact number)'''
        try:
            number = int(input("Number: "))
            if number < 1 or number > len(self.contacts):
                print("Invalid Contact Number.")
                raise IndexError
            return number
        except ValueError:
            print("Invalid integer.")
            print()
            return -1
        except IndexError:
            print()
            return -1

    def display(self):
        '''Displays all contacts'''
        if len(self.contacts) == 0:
            print("There are no contacts available!")
        else:
            for i, row in enumerate(self.contacts, start=1):
                print(f'{i}. {row[0]}')

    def add(self):
        '''Adds a contact'''
        name = input("Name: ")
        email = input("Email: ")
        phone = input("Phone: ")
        contact = [name, email, phone]
        self.contacts.append(contact)
        self.write_contacts_to_file()
        print(f'{contact[0]} was added. The file "{self.filename}" has been updated accordingly.')

    def view(self):
        '''Views a contact'''
        number = self.get_contact_number()
        if number != -1:
            contact = self.contacts[number - 1]
            print("Name:", contact[0])
            print("Email:", contact[1])
            print("Phone Number:", contact[2])

    def remove(self):
        '''Removes a contact'''
        number = self.get_contact_number()
        if number != -1:
            contact = self.contacts.pop(number - 1)
            self.write_contacts_to_file()
            print(f'{contact[0]} was removed. The file "{self.filename}" has been updated accordingly.')
